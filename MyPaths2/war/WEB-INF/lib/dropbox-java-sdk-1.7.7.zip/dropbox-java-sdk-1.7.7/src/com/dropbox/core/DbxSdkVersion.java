package com.dropbox.core;

public class DbxSdkVersion
{
    public static final String Version = "dev";
}
